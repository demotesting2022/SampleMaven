package com.sample.project;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PRStream;
import com.itextpdf.text.pdf.PdfDictionary;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfObject;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;

public class ItextTestMain {

	public static final String SRC = System.getProperty("user.dir") + "\\InputFile.pdf";
	public static final String DEST = System.getProperty("user.dir") + "\\outPutFile" + new Date().getTime() + ".pdf";
	public static HashMap<String, String> txtMap = new HashMap<>();
	public static PdfStamper stamper;

	public static void main(String[] args) throws IOException, DocumentException {
		File file = new File(DEST);
		file.getParentFile().mkdirs();

		txtMap.put("TASMIYA", "Aneeqa");
		txtMap.put("BANU", "Samreen");
		txtMap.put("SHAIK", "Shaikh");
		txtMap.put("SCS222862", "SCS456787");
		txtMap.put("9th Class", "5th Class");
		txtMap.put("Rupees", "GBP");
		txtMap.put("MAHABOOB BASHA", "Reshma Sultana");
		txtMap.put("Father", "Mother");
		System.out.println("HashMap: " + txtMap);

		processPDF(SRC, DEST);
	}

	public static void processPDF(String src, String dest) throws IOException, DocumentException {
		PdfReader reader = new PdfReader(src);
		int pNumbers = reader.getNumberOfPages();
		PRStream stream;
		/*for (int i= 1 ; i <= pNumbers;i++){
		PdfDictionary  dict = reader.getPageN(i);
		PdfObject  object = dict.getDirectObject(PdfName.CONTENTS);
		if (object instanceof PRStream) {
			stream = (PRStream) object;
			byte[] data = PdfReader.getStreamBytes(stream);
			String dd = new String(data);
			dd = dd.replaceAll("MAHABOOB", "Reshma");
			//dd = dd.replaceAll("TAMIYA", "Aneeqa");
			stream.setData(dd.getBytes());
		}
	    }*/
		for (Entry<String, String> entry : txtMap.entrySet()) {
			String oldTxt = entry.getKey();
			String newTxt = entry.getValue();
			System.out.println(oldTxt);
			System.out.println(newTxt);
			for (int i = 1; i <= pNumbers; i++) {
				PdfDictionary dict = reader.getPageN(i);
				PdfObject object = dict.getDirectObject(PdfName.CONTENTS);
				if (object instanceof PRStream) {
					stream = (PRStream) object;
					byte[] data = PdfReader.getStreamBytes(stream);
					String dd = new String(data);
					dd = dd.replaceAll(oldTxt, newTxt);
					stream.setData(dd.getBytes());
				}
			}
		}

		stamper = new PdfStamper(reader, new FileOutputStream(dest));
		stamper.close();
		reader.close();
	}
}