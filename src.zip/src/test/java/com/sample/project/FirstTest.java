package com.sample.project;

import org.openqa.selenium.WebDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FirstTest {

	public static void main(String[] args) {
		WebDriver driver = WebDriverManager.edgedriver().create();
		driver.navigate().to("https://www.google.in");
		driver.manage().window().maximize();
		System.out.println("Title page- " + driver.getTitle());
		System.out.println("Get current URL - " + driver.getCurrentUrl());

		driver.quit();
	}

}
